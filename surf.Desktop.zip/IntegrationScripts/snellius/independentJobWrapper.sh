#!/bin/sh
# This wrapper script is intended to support independent execution.
#
# This script uses the following environment variables set by the submit MATLAB code:
# PARALLEL_SERVER_MATLAB_EXE  - the MATLAB executable to use
# PARALLEL_SERVER_MATLAB_ARGS - the MATLAB args to use

# Copyright 2010-2024 The MathWorks, Inc.

if [ ! $TZ ] ; then
    export TZ=$(timedatectl | grep "Time zone" | cut -d ":" -f2 | cut -d " " -f2)
fi

######################################################################################################
#MW: SURF creates a software stack, based on a year (e.g., 2024).  In that stack is a smaller number
#    of MATLAB installs (e.g., R2024a, R2024b, and maybe R2025a).  A MATLAB release may be in multiple
#    years (e.g., R2025a might be in 2024 and 2025 -- they are identical).  The format is
#
#       /sw/arch/<RHELX>/EB_production/YEAR/sofware/MATLAB/20XXy.
#
#    CMR is based on this.  Because YEAR (and ARCH) can be different for each release of MATLAB, we
#    can't create a specific pattern (e.g., /opt/MATLAB).  Therefore, we need to determine at
#    runtime the location of MATLAB.  `module spider` will search for the proper module(s) to call,
#    based on a version of MATLAB, to load (and therefore find) MATLAB.
#
#    To do this, the *SubmitFcn() needs to pass the version of MATLAB to load
#    (${PARALLEL_MATLAB_RELEASE}).  `modudule spider` will then return one or more years, of which
#    we'll always choose the latest year.  This then gives us the proper module args to load MATLAB
#    and then find it on the path.
#
#       module load $YEAR MATLAB/$RELEASE
#
#    Then set PARALLEL_SERVER_CMR to `which matlab`, then remove the latest two file parts
#    (i.e., /bin/matlab)
#
#    Last, we replace the placeholder "SET-ME-LATER" with the path leading up to the worker executable
#    (i.e., SET-ME-LATER/bin/worker) with the $CMR/bin/worker).
######################################################################################################

YEAR=$(module -t spider MATLAB/${PARALLEL_MATLAB_RELEASE} 2>&1)
# Remove empty lines from the variable and, in case of multiple years, get the last year
YEAR=$(echo "$YEAR" | sed '/^\s*$/d' | tail -n 1)
module load ${YEAR} MATLAB/${PARALLEL_MATLAB_RELEASE}
STATUS=$?
if [ "${STATUS}" -ne 0 ] ; then
    echo "Failed to locate MATLAB on the path.  Exiting with code ${STATUS}."
    exit ${STATUS}
fi 

# If PARALLEL_SERVER_ environment variables are not set, assign any
# available values with form MDCE_ for backwards compatibility
PARALLEL_SERVER_CMR=$(dirname $(dirname `which matlab`))
PARALLEL_SERVER_MATLAB_EXE=${PARALLEL_SERVER_MATLAB_EXE:="${MDCE_MATLAB_EXE}"}
PARALLEL_SERVER_MATLAB_EXE=${PARALLEL_SERVER_MATLAB_EXE/SET-ME-LATER/${PARALLEL_SERVER_CMR}}
PARALLEL_SERVER_MATLAB_ARGS=${PARALLEL_SERVER_MATLAB_ARGS:="${MDCE_MATLAB_ARGS}"}

# Echo the node that the scheduler has allocated to this job:
echo "The scheduler has allocated the following node to this job: `hostname`"

if [ ! -z "${SLURM_ARRAY_TASK_ID}" ] ; then
    # Use job arrays
    TASK_ID=$((${SLURM_ARRAY_TASK_ID}+${PARALLEL_SERVER_TASK_ID_OFFSET}))
    export PARALLEL_SERVER_TASK_LOCATION="${PARALLEL_SERVER_JOB_LOCATION}/Task${TASK_ID}";
    export MDCE_TASK_LOCATION="${MDCE_JOB_LOCATION}/Task${TASK_ID}";
fi

# Construct the command to run.
CMD="\"${PARALLEL_SERVER_MATLAB_EXE}\" ${PARALLEL_SERVER_MATLAB_ARGS}"

# Echo the command so that it is shown in the output log.
echo "Executing: $CMD"

# Execute the command.
echo
echo "START: $(date)"
time eval $CMD
EXIT_CODE=${?}
echo "END: $(date)"
echo

echo "Exiting with code: ${EXIT_CODE}"
exit ${EXIT_CODE}
