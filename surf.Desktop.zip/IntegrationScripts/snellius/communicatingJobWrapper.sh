#!/bin/sh
# This wrapper script is intended to be submitted to Slurm to support
# communicating jobs.
#
# This script uses the following environment variables set by the submit MATLAB code:
# PARALLEL_SERVER_CMR         - the value of ClusterMatlabRoot (may be empty)
# PARALLEL_SERVER_MATLAB_EXE  - the MATLAB executable to use
# PARALLEL_SERVER_MATLAB_ARGS - the MATLAB args to use
# PARALLEL_SERVER_TOTAL_TASKS - total number of workers to start
# PARALLEL_SERVER_NUM_THREADS - number of cores needed per worker
# PARALLEL_SERVER_DEBUG       - used to debug problems on the cluster
#
# The following environment variables are forwarded through mpiexec:
# PARALLEL_SERVER_DECODE_FUNCTION     - the decode function to use
# PARALLEL_SERVER_STORAGE_LOCATION    - used by decode function
# PARALLEL_SERVER_STORAGE_CONSTRUCTOR - used by decode function
# PARALLEL_SERVER_JOB_LOCATION        - used by decode function
#
# The following environment variables are set by Slurm:
# SLURM_NODELIST - list of hostnames allocated to this Slurm job

# Copyright 2015-2025 The MathWorks, Inc.

if [ ! $TZ ] ; then
    export TZ=$(timedatectl | grep "Time zone" | cut -d ":" -f2 | cut -d " " -f2)
fi

######################################################################################################
#MW: SURF creates a software stack, based on a year (e.g., 2024).  In that stack is a smaller number
#    of MATLAB installs (e.g., R2024a, R2024b, and maybe R2025a).  A MATLAB release may be in multiple
#    years (e.g., R2025a might be in 2024 and 2025 -- they are identical).  The format is
#
#       /sw/arch/<RHELX>/EB_production/YEAR/sofware/MATLAB/20XXy.
#
#    CMR is based on this.  Because YEAR (and ARCH) can be different for each release of MATLAB, we
#    can't create a specific pattern (e.g., /opt/MATLAB).  Therefore, we need to determine at
#    runtime the location of MATLAB.  `module spider` will search for the proper module(s) to call,
#    based on a version of MATLAB, to load (and therefore find) MATLAB.
#
#    To do this, the *SubmitFcn() needs to pass the version of MATLAB to load
#    (${PARALLEL_MATLAB_RELEASE}).  `modudule spider` will then return one or more years, of which
#    we'll always choose the latest year.  This then gives us the proper module args to load MATLAB
#    and then find it on the path.
#
#       module load $YEAR MATLAB/$RELEASE
#
#    Then set PARALLEL_SERVER_CMR to `which matlab`, then remove the latest two file parts
#    (i.e., /bin/matlab)
#
#    Last, we replace the placeholder "SET-ME-LATER" with the path leading up to the worker executable
#    (i.e., SET-ME-LATER/bin/worker) with the $CMR/bin/worker).
######################################################################################################

YEAR=$(module -t spider MATLAB/${PARALLEL_MATLAB_RELEASE} 2>&1)
# Remove empty lines from the variable and, in case of multiple years, get the last year
YEAR=$(echo "$YEAR" | sed '/^\s*$/d' | tail -n 1)
module load ${YEAR} MATLAB/${PARALLEL_MATLAB_RELEASE}
STATUS=$?
if [ "${STATUS}" -ne 0 ] ; then
    echo "Failed to locate MATLAB on the path.  Exiting with code ${STATUS}."
    exit ${STATUS}
fi 

# If PARALLEL_SERVER_ environment variables are not set, assign any
# available values with form MDCE_ for backwards compatibility
#PARALLEL_SERVER_CMR=${PARALLEL_SERVER_CMR:="${MDCE_CMR}"}
PARALLEL_SERVER_CMR=$(dirname $(dirname `which matlab`))
PARALLEL_SERVER_MATLAB_EXE=${PARALLEL_SERVER_MATLAB_EXE:="${MDCE_MATLAB_EXE}"}
PARALLEL_SERVER_MATLAB_EXE=${PARALLEL_SERVER_MATLAB_EXE/SET-ME-LATER/${PARALLEL_SERVER_CMR}}
PARALLEL_SERVER_MATLAB_ARGS=${PARALLEL_SERVER_MATLAB_ARGS:="${MDCE_MATLAB_ARGS}"}
PARALLEL_SERVER_TOTAL_TASKS=${PARALLEL_SERVER_TOTAL_TASKS:="${MDCE_TOTAL_TASKS}"}
PARALLEL_SERVER_NUM_THREADS=${PARALLEL_SERVER_NUM_THREADS:="${MDCE_NUM_THREADS}"}
PARALLEL_SERVER_DEBUG=${PARALLEL_SERVER_DEBUG:="${MDCE_DEBUG}"}

# Other environment variables to forward
PARALLEL_SERVER_GENVLIST="${PARALLEL_SERVER_GENVLIST},HOME,USER,TZ"

# Echo the nodes that the scheduler has allocated to this job:
echo -e "The scheduler has allocated the following nodes to this job:\n${SLURM_NODELIST:?"Node list undefined"}"

# Create full path to mw_mpiexec if needed.
FULL_MPIEXEC=${PARALLEL_SERVER_CMR:+${PARALLEL_SERVER_CMR}/bin/}mw_mpiexec

# Label stdout/stderr with the rank of the process
MPI_VERBOSE=-l

# Increase the verbosity of mpiexec if PARALLEL_SERVER_DEBUG is set and not false
if [ ! -z "${PARALLEL_SERVER_DEBUG}" ] && [ "${PARALLEL_SERVER_DEBUG}" != "false" ] ; then
    MPI_VERBOSE="${MPI_VERBOSE} -v -print-all-exitcodes"
fi

if [ ! -z "${PARALLEL_SERVER_BIND_TO_CORE}" ] && [ "${PARALLEL_SERVER_BIND_TO_CORE}" != "false" ] ; then
    BIND_TO_CORE_ARG="-bind-to core:${PARALLEL_SERVER_NUM_THREADS}"
else
    BIND_TO_CORE_ARG=""
fi

# Construct the command to run.
CMD="\"${FULL_MPIEXEC}\" \
    ${PARALLEL_SERVER_MPIEXEC_ARG} \
    -genvlist ${PARALLEL_SERVER_GENVLIST} \
    ${BIND_TO_CORE_ARG} \
    ${MPI_VERBOSE} \
    -n ${PARALLEL_SERVER_TOTAL_TASKS} \
    \"${PARALLEL_SERVER_MATLAB_EXE}\" \
    ${PARALLEL_SERVER_MATLAB_ARGS}"

# Echo the command so that it is shown in the output log.
echo $CMD

# Execute the command.
echo
echo "START: $(date)"
time eval $CMD
MPIEXEC_EXIT_CODE=${?}
echo "END: $(date)"
echo

if [ ${MPIEXEC_EXIT_CODE} -eq 42 ] ; then
    # Get here if user code errored out within MATLAB. Overwrite this to zero in
    # this case.
    echo "Overwriting MPIEXEC exit code from 42 to zero (42 indicates a user-code failure)"
    MPIEXEC_EXIT_CODE=0
fi
echo "Exiting with code: ${MPIEXEC_EXIT_CODE}"
exit ${MPIEXEC_EXIT_CODE}
